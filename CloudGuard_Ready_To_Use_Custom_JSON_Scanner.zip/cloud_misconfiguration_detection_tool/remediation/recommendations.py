ACTIONS = {
 "storage": "Restrict public access, enable encryption, and review access logging.",
 "network": "Limit inbound rules to trusted IP ranges and required ports.",
 "identity": "Apply least privilege, enable MFA, and disable unused accounts.",
 "compute": "Enable disk encryption, monitoring, and timely security updates.",
 "database": "Disable public access, enable encryption and backups, and strengthen authentication."
}
PRIORITY = {"CRITICAL": "Immediate", "HIGH": "High", "MEDIUM": "Planned", "LOW": "Routine"}

def enrich(findings):
    for item in findings:
        item["recommendation"] = ACTIONS.get(item["category"], "Review the resource configuration.")
        item["priority"] = PRIORITY.get(item["severity"], "Routine")
    return findings
