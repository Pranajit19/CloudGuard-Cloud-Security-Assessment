import sqlite3
from pathlib import Path
from datetime import datetime, timezone
import json

DB_PATH = Path(__file__).resolve().parent / "cloud_audit.db"

class AuditDatabase:
    def __init__(self, path=DB_PATH):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def connect(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys = ON")
        return con

    def initialize(self):
        with self.connect() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT NOT NULL,
                dataset TEXT NOT NULL, finding_count INTEGER NOT NULL,
                total_risk_score INTEGER NOT NULL, average_risk_score REAL NOT NULL,
                overall_risk TEXT NOT NULL)""")
            con.execute("""CREATE TABLE IF NOT EXISTS findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT, scan_id INTEGER NOT NULL,
                resource_id TEXT, resource_name TEXT, category TEXT, rule_id TEXT,
                title TEXT, description TEXT, severity TEXT, risk_score INTEGER,
                recommendation TEXT, priority TEXT, compliance_refs TEXT,
                FOREIGN KEY(scan_id) REFERENCES scans(id) ON DELETE CASCADE)""")

    def save_scan(self, dataset, summary, findings):
        with self.connect() as con:
            cur = con.execute("""INSERT INTO scans
                (timestamp,dataset,finding_count,total_risk_score,average_risk_score,overall_risk)
                VALUES (?,?,?,?,?,?)""",
                (datetime.now(timezone.utc).isoformat(timespec="seconds"), dataset,
                 summary["finding_count"], summary["total_risk_score"],
                 summary["average_risk_score"], summary["overall_risk"]))
            scan_id = cur.lastrowid
            for f in findings:
                con.execute("""INSERT INTO findings
                (scan_id,resource_id,resource_name,category,rule_id,title,description,severity,
                 risk_score,recommendation,priority,compliance_refs)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                 (scan_id, f.get("resource_id"), f.get("resource_name"), f.get("category"),
                  f.get("rule_id"), f.get("title"), f.get("description"), f.get("severity"),
                  f.get("risk_score"), f.get("recommendation"), f.get("priority"),
                  json.dumps(f.get("compliance_refs", []))))
            return scan_id

    def history(self, limit=20):
        with self.connect() as con:
            return [dict(r) for r in con.execute("SELECT * FROM scans ORDER BY id DESC LIMIT ?", (limit,))]

    def findings(self, scan_id):
        with self.connect() as con:
            rows = [dict(r) for r in con.execute("SELECT * FROM findings WHERE scan_id=? ORDER BY risk_score DESC, id", (scan_id,))]
        for row in rows:
            row["compliance_refs"] = json.loads(row.get("compliance_refs") or "[]")
        return rows

    def latest_scan(self):
        rows = self.history(1)
        return rows[0] if rows else None

    def delete_scan(self, scan_id):
        with self.connect() as con:
            con.execute("DELETE FROM findings WHERE scan_id=?", (scan_id,))
            con.execute("DELETE FROM scans WHERE id=?", (scan_id,))

    def clear_history(self):
        with self.connect() as con:
            con.execute("DELETE FROM findings")
            con.execute("DELETE FROM scans")
