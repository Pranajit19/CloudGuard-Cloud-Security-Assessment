WEIGHTS = {"LOW": 2, "MEDIUM": 5, "HIGH": 8, "CRITICAL": 10}

def score_findings(findings):
    for finding in findings:
        finding["risk_score"] = WEIGHTS.get(finding["severity"], 2)
    scores = [f["risk_score"] for f in findings]
    total = sum(scores)
    average = round(total / len(scores), 2) if scores else 0
    if any(f["severity"] == "CRITICAL" for f in findings) or total >= 40:
        overall = "CRITICAL"
    elif total >= 20:
        overall = "HIGH"
    elif total >= 8:
        overall = "MEDIUM"
    else:
        overall = "LOW"
    return findings, {"finding_count": len(findings), "total_risk_score": total,
                      "average_risk_score": average, "overall_risk": overall}
