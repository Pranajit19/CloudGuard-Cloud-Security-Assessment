import json
from pathlib import Path

CATEGORIES = ("storage", "network", "identity", "compute", "database")

class ConfigurationParser:
    def load_all_configurations(self, dataset_dir):
        data = {}
        root = Path(dataset_dir)
        for category in CATEGORIES:
            path = root / f"{category}.json"
            if not path.exists():
                raise FileNotFoundError(f"Required configuration file missing: {path}")
            with path.open("r", encoding="utf-8") as handle:
                parsed = json.load(handle)
            if not isinstance(parsed, list):
                raise ValueError(f"{path} must contain a JSON list")
            data[category] = parsed
        return data
