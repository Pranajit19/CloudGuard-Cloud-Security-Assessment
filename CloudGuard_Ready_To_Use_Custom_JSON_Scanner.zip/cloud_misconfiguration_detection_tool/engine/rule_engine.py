from rules.checks import RULES

class RuleEngine:
    def run(self, configurations):
        findings = []
        for category, resources in configurations.items():
            for resource in resources:
                for rule in RULES:
                    if rule["category"] == category and rule["check"](resource):
                        findings.append({
                            "resource_id": str(resource.get("id", "unknown")),
                            "resource_name": str(resource.get("name", "Unnamed resource")),
                            "category": category,
                            "rule_id": rule["id"],
                            "title": rule["title"],
                            "description": rule["description"],
                            "severity": rule["severity"],
                        })
        return findings
