import html
import json
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

class ReportExporter:
    def __init__(self, db):
        self.db = db

    def export(self, scan_id, fmt):
        scan = next((s for s in self.db.history(1000) if s["id"] == scan_id), None)
        if not scan:
            raise ValueError("Scan not found")
        findings = self.db.findings(scan_id)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if fmt == "json":
            path = REPORTS / f"scan_{scan_id}_{stamp}.json"
            path.write_text(json.dumps({"scan": scan, "findings": findings}, indent=2), encoding="utf-8")
        elif fmt == "html":
            path = REPORTS / f"scan_{scan_id}_{stamp}.html"
            rows = "".join(
                "<tr>" + "".join(f"<td>{html.escape(str(f.get(k, '')))}</td>" for k in ("resource_name","category","title","severity","risk_score","recommendation")) + "</tr>"
                for f in findings
            )
            body = f"""<!doctype html><html><head><meta charset="utf-8"><title>Cloud Audit Report</title>
            <style>body{{font-family:Arial;margin:30px}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ccc;padding:8px;text-align:left}}th{{background:#17324d;color:white}}</style></head>
            <body><h1>Cloud Security Assessment Report</h1><p>Scan #{scan_id} | Dataset: {html.escape(scan['dataset'])} | Risk: {html.escape(scan['overall_risk'])}</p>
            <p>Prototype report based on simulated configuration data.</p><table><thead><tr><th>Resource</th><th>Category</th><th>Finding</th><th>Severity</th><th>Score</th><th>Recommendation</th></tr></thead><tbody>{rows}</tbody></table></body></html>"""
            path.write_text(body, encoding="utf-8")
        else:
            raise ValueError("Unsupported report format")
        return path
