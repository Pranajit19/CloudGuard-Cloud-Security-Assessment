# Cloud Misconfiguration Detection and Security Posture Assessment Tool

A Flask student project with a dashboard, SQLite scan history, risk scoring, remediation recommendations, compliance references, and JSON/HTML reports. It supports both simulated demonstration scans and starter read-only inventory scans for AWS, Azure, and Google Cloud.

## Run on Windows
1. Install Python 3.10+.
2. Extract the ZIP.
3. Open the extracted folder and double-click `run.bat` (or run it from Command Prompt).
4. Open `http://127.0.0.1:5000`.

The installer creates/uses the local virtual environment and installs SDK dependencies. If your network blocks package installation, install dependencies from a network that permits PyPI access.

## Run on macOS/Linux
```bash
chmod +x run.sh
./run.sh
```

## Live provider scans
See **Cloud setup** in the dashboard for provider-specific setup, least-privilege permissions, supported checks, and limitations.

- AWS: uses local boto3/AWS CLI credentials; set `AWS_DEFAULT_REGION` to the region you want to scan. S3 is global, but EC2 security groups, EC2 instances/volumes, and RDS are scanned in that one region.
- Azure: uses Azure CLI/DefaultAzureCredential and Resource Graph to inspect subscriptions visible to the signed-in identity.
- Google Cloud: uses Application Default Credentials and Cloud Asset Inventory. Set `GOOGLE_CLOUD_PROJECT` to the project ID to scan.

**Security:** do not paste cloud credentials into chat, source files, or web forms. Do not use root/Owner/Administrator credentials. Grant only required read/list/describe permissions. This app only uses read APIs and does not modify cloud resources. Keep the local Flask server bound to `127.0.0.1`; do not expose it publicly.

## Important limitations
This is a student project starter, not a certified cloud security scanner. Cloud API shapes and permissions vary, and current live checks cover only a subset of each provider's services and controls. Findings should be manually verified. A clean scan is not proof that a cloud account is secure. Risk scores are project-defined prioritization values, not probabilities of compromise.

## Existing data
The SQLite database remains at `database/cloud_audit.db`. Simulated datasets are retained for offline demonstrations. Live scans are saved in the same history and use the same finding scoring and report export pipeline.

## Custom JSON scan (no cloud account required)

1. Start the app with `run.bat` on Windows or `./run.sh` on macOS/Linux.
2. Open `http://127.0.0.1:5000`.
3. Select **JSON scan** in the top navigation, or open `/custom-scan`.
4. Download the example JSON, edit it if desired, and upload it to run the local rule engine.
5. Findings are saved to the same SQLite history and can be exported as JSON or HTML.

Custom JSON scans inspect only the data supplied in the file. They are not live cloud scans. The live AWS/Azure/GCP buttons require accounts, local CLI authentication, and appropriate read-only permissions. No scan changes cloud resources.

Accepted input formats:
- An object with lists named `storage`, `network`, `identity`, `compute`, and/or `database`.
- A list of resource objects, each with a `category` field set to one of those five category names.

Only fields checked by the rules in `rules/checks.py` can trigger findings. The app accepts JSON files up to 1 MB.
