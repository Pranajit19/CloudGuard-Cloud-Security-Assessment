"""Read-only cloud inventory collectors for AWS, Azure, and Google Cloud."""
