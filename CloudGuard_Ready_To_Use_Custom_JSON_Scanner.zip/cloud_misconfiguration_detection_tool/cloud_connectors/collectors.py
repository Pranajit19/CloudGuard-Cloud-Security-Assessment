"""Read-only cloud collectors. They only call list/describe/search APIs; no mutation APIs."""
from __future__ import annotations
import os

CATEGORIES = ("storage", "network", "identity", "compute", "database")

def empty_inventory():
    return {key: [] for key in CATEGORIES}

def _err(provider, message):
    raise RuntimeError(f"{provider} scan could not complete: {message}")

def collect_aws():
    """Collect a starter security posture snapshot using boto3 read-only APIs."""
    try:
        import boto3
        from botocore.exceptions import BotoCoreError, ClientError
    except ImportError:
        _err("AWS", "AWS SDK missing. Run: pip install -r requirements.txt")
    try:
        session = boto3.Session()
        sts = session.client("sts")
        identity = sts.get_caller_identity()
        region = os.getenv("AWS_DEFAULT_REGION") or session.region_name or "us-east-1"
        s3 = session.client("s3", region_name=region)
        ec2 = session.client("ec2", region_name=region)
        rds = session.client("rds", region_name=region)
        iam = session.client("iam")
        data = empty_inventory()
        account = identity.get("Account", "unknown")

        # S3: bucket policy/public-access block, default encryption, versioning, access logging.
        for bucket in s3.list_buckets().get("Buckets", []):
            name = bucket["Name"]
            def safe_call(method, **kwargs):
                try: return method(**kwargs)
                except ClientError as exc:
                    code = exc.response.get("Error", {}).get("Code", "")
                    if code in {"NoSuchPublicAccessBlockConfiguration", "ServerSideEncryptionConfigurationNotFoundError", "NoSuchBucketPolicy", "NoSuchTagSet"}:
                        return None
                    if code in {"AccessDenied", "AccessDeniedException", "AllAccessDisabled"}:
                        return {"_access_denied": True}
                    raise
            public_block = safe_call(s3.get_public_access_block, Bucket=name)
            pab = (public_block or {}).get("PublicAccessBlockConfiguration", {}) if not (public_block or {}).get("_access_denied") else {}
            policy_status = safe_call(s3.get_bucket_policy_status, Bucket=name)
            public_policy = bool(((policy_status or {}).get("PolicyStatus") or {}).get("IsPublic", False))
            encryption = safe_call(s3.get_bucket_encryption, Bucket=name)
            versioning = safe_call(s3.get_bucket_versioning, Bucket=name)
            logging = safe_call(s3.get_bucket_logging, Bucket=name)
            acl = safe_call(s3.get_bucket_acl, Bucket=name)
            acl_public = any(g.get("Grantee", {}).get("URI", "").endswith(("/AllUsers", "/AuthenticatedUsers"))
                             for g in (acl or {}).get("Grants", [])) if not (acl or {}).get("_access_denied") else False
            data["storage"].append({
                "id": f"arn:aws:s3:::{name}", "name": name,
                "public_access": public_policy or acl_public,
                "encryption": bool((encryption or {}).get("ServerSideEncryptionConfiguration")),
                "versioning": (versioning or {}).get("Status") == "Enabled",
                "logging": bool((logging or {}).get("LoggingEnabled")),
                "provider": "AWS", "region": "global", "account_id": account,
            })

        # Security groups: one normalized record per ingress permission/range.
        for sg in ec2.describe_security_groups().get("SecurityGroups", []):
            for permission in sg.get("IpPermissions", []):
                port_from = permission.get("FromPort", -1); port_to = permission.get("ToPort", -1)
                proto = permission.get("IpProtocol", "")
                for ip_range in permission.get("IpRanges", []):
                    cidr = ip_range.get("CidrIp", "")
                    data["network"].append({"id": sg["GroupId"], "name": sg.get("GroupName", sg["GroupId"]),
                        "port": port_from if port_from == port_to else -1,
                        "source": cidr, "direction": "inbound", "all_ports_public": proto == "-1" and cidr == "0.0.0.0/0",
                        "firewall_enabled": True, "provider": "AWS", "region": region, "account_id": account})

        # EC2 instances and EBS volume encryption.
        for reservation in ec2.describe_instances().get("Reservations", []):
            for inst in reservation.get("Instances", []):
                iid = inst["InstanceId"]
                for mapping in inst.get("BlockDeviceMappings", []):
                    volume_id = (mapping.get("Ebs") or {}).get("VolumeId")
                    if volume_id:
                        try:
                            vol = ec2.describe_volumes(VolumeIds=[volume_id]).get("Volumes", [{}])[0]
                            data["compute"].append({"id": volume_id, "name": f"{iid} / {volume_id}",
                                "public_ip": bool(inst.get("PublicIpAddress")), "disk_encrypted": bool(vol.get("Encrypted")),
                                "monitoring": inst.get("Monitoring", {}).get("State") == "enabled",
                                "provider": "AWS", "region": region, "account_id": account})
                        except ClientError:
                            pass
                if not inst.get("BlockDeviceMappings"):
                    data["compute"].append({"id": iid, "name": iid, "public_ip": bool(inst.get("PublicIpAddress")),
                        "disk_encrypted": True, "monitoring": inst.get("Monitoring", {}).get("State") == "enabled",
                        "provider": "AWS", "region": region, "account_id": account})

        # RDS database configuration.
        for dbi in rds.describe_db_instances().get("DBInstances", []):
            data["database"].append({"id": dbi.get("DBInstanceArn", dbi["DBInstanceIdentifier"]),
                "name": dbi["DBInstanceIdentifier"], "public_access": bool(dbi.get("PubliclyAccessible")),
                "encryption": bool(dbi.get("StorageEncrypted")), "backups": int(dbi.get("BackupRetentionPeriod", 0)) > 0,
                "audit_logging": bool(dbi.get("EnabledCloudwatchLogsExports")), "provider": "AWS", "region": region, "account_id": account})

        # IAM MFA inventory (users only; does not inspect federated identity policies).
        for user in iam.list_users().get("Users", []):
            mfa = iam.list_mfa_devices(UserName=user["UserName"]).get("MFADevices", [])
            data["identity"].append({"id": user.get("Arn", user["UserName"]), "name": user["UserName"],
                "mfa_enabled": bool(mfa), "enabled": True, "provider": "AWS", "account_id": account})
        return data, f"AWS account {account} · region {region}"
    except Exception as exc:
        _err("AWS", str(exc))

def collect_azure():
    """Read resource inventory with Azure Resource Graph; no write operations."""
    try:
        from azure.identity import DefaultAzureCredential
        from azure.mgmt.resourcegraph import ResourceGraphClient
        from azure.mgmt.resourcegraph.models import QueryRequest
        from azure.mgmt.subscription import SubscriptionClient
    except ImportError:
        _err("Azure", "Azure SDK missing. Run: pip install -r requirements.txt")
    try:
        credential = DefaultAzureCredential(exclude_interactive_browser_credential=False)
        subs = [s.subscription_id for s in SubscriptionClient(credential).subscriptions.list()]
        if not subs:
            _err("Azure", "No subscriptions visible to this login. Sign in and grant Reader access.")
        client = ResourceGraphClient(credential)
        query = "Resources | project id, name, type, location, properties | limit 1000"
        result = client.resources(QueryRequest(subscriptions=subs, query=query))
        data = empty_inventory()
        for row in result.data or []:
            typ = str(row.get("type", "")).lower(); props = row.get("properties") or {}
            rid = row.get("id", row.get("name", "unknown")); name = row.get("name", rid)
            common = {"id": rid, "name": name, "provider": "Azure", "region": row.get("location", "unknown"), "subscription_id": rid.split("/")[2] if len(rid.split("/")) > 2 else ""}
            if typ == "microsoft.storage/storageaccounts":
                network = props.get("networkAcls") or {}
                data["storage"].append({**common, "public_access": str(props.get("allowBlobPublicAccess", "false")).lower() == "true",
                    "encryption": bool((props.get("encryption") or {}).get("services")), "versioning": bool(((props.get("blobServices") or {}).get("defaultServiceVersion"))),
                    "logging": bool((props.get("logging") or {}).get("read"))})
            elif typ == "microsoft.network/networksecuritygroups":
                for rule in props.get("securityRules", []) or []:
                    source = rule.get("sourceAddressPrefix", "")
                    port = rule.get("destinationPortRange", "")
                    if rule.get("direction") == "Inbound" and rule.get("access") == "Allow":
                        data["network"].append({**common, "id": f"{rid}/{rule.get('name','rule')}", "name": f"{name} / {rule.get('name','rule')}",
                            "port": int(port) if str(port).isdigit() else -1, "source": "0.0.0.0/0" if source in ("*", "Internet", "0.0.0.0/0") else source,
                            "direction": "inbound", "all_ports_public": port == "*" and source in ("*", "Internet", "0.0.0.0/0"), "firewall_enabled": True})
            elif typ == "microsoft.compute/virtualmachines":
                storage = props.get("storageProfile") or {}; osdisk = storage.get("osDisk") or {}; enc = osdisk.get("encryptionSettings") or {}
                data["compute"].append({**common, "public_ip": False, "disk_encrypted": bool(enc.get("enabled")), "monitoring": bool((props.get("diagnosticsProfile") or {}).get("bootDiagnostics", {}).get("enabled"))})
            elif typ == "microsoft.sql/servers":
                data["database"].append({**common, "public_access": str(props.get("publicNetworkAccess", "Enabled")).lower() != "disabled",
                    "encryption": True, "backups": True, "audit_logging": bool(props.get("auditingSettings"))})
        return data, f"Azure subscriptions: {len(subs)} · resources returned: {len(result.data or [])}"
    except Exception as exc:
        _err("Azure", str(exc))

def collect_gcp():
    """Read Cloud Asset Inventory for one explicitly configured GCP project."""
    project = os.getenv("GOOGLE_CLOUD_PROJECT") or os.getenv("GCLOUD_PROJECT")
    if not project:
        _err("Google Cloud", "Set GOOGLE_CLOUD_PROJECT to the project ID you want to assess.")
    try:
        from google.cloud import asset_v1
    except ImportError:
        _err("Google Cloud", "Google Cloud SDK missing. Run: pip install -r requirements.txt")
    try:
        client = asset_v1.AssetServiceClient()
        scope = f"projects/{project}"
        request = asset_v1.SearchAllResourcesRequest(scope=scope, page_size=500,
            asset_types=["storage.googleapis.com/Bucket", "compute.googleapis.com/Firewall", "compute.googleapis.com/Instance", "sqladmin.googleapis.com/Instance"])
        data = empty_inventory(); count = 0
        for asset in client.search_all_resources(request=request):
            count += 1
            typ = asset.asset_type or ""; name = asset.display_name or asset.name.rsplit("/", 1)[-1]
            props = dict(asset.additional_attributes or {})
            common = {"id": asset.name, "name": name, "provider": "Google Cloud", "project_id": project, "region": asset.location or "global"}
            if typ.endswith("/Bucket"):
                iam = props.get("iamConfiguration") or {}; enc = props.get("encryption") or {}
                versioning = props.get("versioning") or {}; logging = props.get("logging") or {}
                data["storage"].append({**common, "public_access": str(iam.get("publicAccessPrevention", "")).lower() == "disabled",
                    "encryption": True, "versioning": bool(versioning.get("enabled")), "logging": bool(logging.get("logBucket"))})
            elif typ.endswith("/Firewall"):
                for source in props.get("sourceRanges", []) or []:
                    for allowed in props.get("allowed", []) or []:
                        proto = allowed.get("IPProtocol", ""); ports = allowed.get("ports", [])
                        for p in ports or (["*"] if proto == "all" else []):
                            data["network"].append({**common, "port": int(p) if str(p).isdigit() else -1, "source": source,
                                "direction": str(props.get("direction", "INGRESS")).lower(), "all_ports_public": source == "0.0.0.0/0" and (proto == "all" or not ports), "firewall_enabled": True})
            elif typ.endswith("/Instance") and "sqladmin" not in typ:
                disks = props.get("disks", []) or []
                for disk in disks or [{}]:
                    data["compute"].append({**common, "id": f"{asset.name}/{disk.get('deviceName','disk')}", "public_ip": any(bool(ni.get("accessConfigs")) for ni in (props.get("networkInterfaces", []) or [])),
                        "disk_encrypted": True, "monitoring": True})
            elif typ.endswith("sqladmin.googleapis.com/Instance") or "sqladmin" in typ:
                settings = props.get("settings") or {}; ipconfig = (props.get("ipConfiguration") or {})
                data["database"].append({**common, "public_access": bool(ipconfig.get("authorizedNetworks")), "encryption": True,
                    "backups": bool((settings.get("backupConfiguration") or {}).get("enabled")), "audit_logging": True})
        return data, f"Google Cloud project {project} · resources returned: {count}"
    except Exception as exc:
        _err("Google Cloud", str(exc))

COLLECTORS = {"aws": collect_aws, "azure": collect_azure, "gcp": collect_gcp}
