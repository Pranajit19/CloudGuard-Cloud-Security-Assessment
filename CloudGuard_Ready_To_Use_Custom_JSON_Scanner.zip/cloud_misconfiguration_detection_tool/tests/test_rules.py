import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from engine.parser import ConfigurationParser
from engine.rule_engine import RuleEngine
from engine.risk_engine import score_findings

class ProjectTests(unittest.TestCase):
    def test_parser_loads_five_categories(self):
        data = ConfigurationParser().load_all_configurations(ROOT / "cloud_data/datasets/retail")
        self.assertEqual(set(data), {"storage", "network", "identity", "compute", "database"})

    def test_public_storage_is_detected(self):
        findings = RuleEngine().run({"storage": [{"id":"x","name":"test","public_access":True}]})
        self.assertTrue(any(f["rule_id"] == "ST-01" for f in findings))

    def test_risk_summary(self):
        findings, summary = score_findings([{"severity":"CRITICAL"}])
        self.assertEqual(findings[0]["risk_score"], 10)
        self.assertEqual(summary["finding_count"], 1)
        self.assertEqual(summary["overall_risk"], "CRITICAL")

if __name__ == "__main__":
    unittest.main()
