# Illustrative references only; these are not certification or a full compliance assessment.
REFERENCES = {
 "storage": ["CIS cloud storage guidance", "NIST access control guidance", "ISO 27001 access control"],
 "network": ["CIS network security guidance", "NIST network protection guidance", "ISO 27001 network security"],
 "identity": ["CIS identity guidance", "NIST identity and access management", "ISO 27001 identity management"],
 "compute": ["CIS compute hardening guidance", "NIST system protection guidance", "ISO 27001 secure configuration"],
 "database": ["CIS database guidance", "NIST data protection guidance", "ISO 27001 information protection"],
}
def enrich(findings):
    for item in findings:
        item["compliance_refs"] = REFERENCES.get(item["category"], [])
    return findings
