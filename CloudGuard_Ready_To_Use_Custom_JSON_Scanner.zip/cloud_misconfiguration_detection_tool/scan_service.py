import json
from pathlib import Path
from engine.parser import ConfigurationParser
from engine.rule_engine import RuleEngine
from engine.risk_engine import score_findings
from remediation.recommendations import enrich as add_recommendations
from compliance.mapping import enrich as add_compliance
from database.database import AuditDatabase

ROOT = Path(__file__).resolve().parent
DATASETS = ["retail", "healthcare", "banking", "startup", "secure_enterprise"]
ROTATION_FILE = ROOT / "cloud_data" / "dataset_rotation.json"

class ScanService:
    def __init__(self, db=None):
        self.db = db or AuditDatabase()
        self.parser = ConfigurationParser()
        self.rules = RuleEngine()

    def run_scan(self):
        try:
            state = json.loads(ROTATION_FILE.read_text(encoding="utf-8"))
            index = int(state.get("next_index", 0)) % len(DATASETS)
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            index = 0
        dataset = DATASETS[index]
        configurations = self.parser.load_all_configurations(ROOT / "cloud_data" / "datasets" / dataset)
        findings = self.rules.run(configurations)
        findings, summary = score_findings(findings)
        findings = add_recommendations(findings)
        findings = add_compliance(findings)
        scan_id = self.db.save_scan(dataset, summary, findings)
        ROTATION_FILE.write_text(json.dumps({"next_index": (index + 1) % len(DATASETS)}, indent=2), encoding="utf-8")
        return scan_id, dataset, summary, findings

    def run_cloud_scan(self, provider):
        """Run a live, read-only inventory scan through a provider adapter."""
        from cloud_connectors.collectors import COLLECTORS
        key = str(provider or "").lower()
        if key not in COLLECTORS:
            raise ValueError("Unsupported cloud provider")
        configurations, scope = COLLECTORS[key]()
        findings = self.rules.run(configurations)
        findings, summary = score_findings(findings)
        findings = add_recommendations(findings)
        findings = add_compliance(findings)
        label = f"{key.upper()} LIVE · {scope}"
        scan_id = self.db.save_scan(label, summary, findings)
        return scan_id, label, summary, findings
