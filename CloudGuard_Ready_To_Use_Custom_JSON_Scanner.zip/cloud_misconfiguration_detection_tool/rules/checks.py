# Demonstration rules. These inspect only the simulated JSON fields.
def truthy(value):
    return value is True or str(value).lower() in {"true", "yes", "1", "enabled"}

def has(value, expected):
    return str(value).lower() == str(expected).lower()

RULES = [
 {"id":"ST-01","category":"storage","title":"Public storage access enabled","description":"Storage is configured for public access.","severity":"CRITICAL","check":lambda r: truthy(r.get("public_access"))},
 {"id":"ST-02","category":"storage","title":"Encryption disabled","description":"Stored data is not marked as encrypted.","severity":"HIGH","check":lambda r: not truthy(r.get("encryption"))},
 {"id":"ST-03","category":"storage","title":"Versioning disabled","description":"Object versioning is not enabled.","severity":"MEDIUM","check":lambda r: not truthy(r.get("versioning"))},
 {"id":"ST-04","category":"storage","title":"Access logging disabled","description":"Storage access logging is not enabled.","severity":"MEDIUM","check":lambda r: not truthy(r.get("logging"))},
 {"id":"ST-05","category":"storage","title":"Unrestricted sharing configured","description":"Sharing scope is set to everyone.","severity":"HIGH","check":lambda r: has(r.get("sharing_scope"), "everyone")},
 {"id":"NW-01","category":"network","title":"SSH exposed to the internet","description":"SSH port 22 is open to all IP addresses.","severity":"HIGH","check":lambda r: r.get("port")==22 and has(r.get("source"), "0.0.0.0/0")},
 {"id":"NW-02","category":"network","title":"RDP exposed to the internet","description":"RDP port 3389 is open to all IP addresses.","severity":"CRITICAL","check":lambda r: r.get("port")==3389 and has(r.get("source"), "0.0.0.0/0")},
 {"id":"NW-03","category":"network","title":"All ports publicly exposed","description":"A broad rule exposes all ports publicly.","severity":"CRITICAL","check":lambda r: truthy(r.get("all_ports_public"))},
 {"id":"NW-04","category":"network","title":"Unrestricted inbound traffic","description":"Inbound traffic source is unrestricted.","severity":"HIGH","check":lambda r: has(r.get("source"), "0.0.0.0/0") and r.get("direction")=="inbound"},
 {"id":"NW-05","category":"network","title":"Firewall disabled","description":"Firewall protection is not enabled.","severity":"HIGH","check":lambda r: not truthy(r.get("firewall_enabled"))},
 {"id":"ID-01","category":"identity","title":"Administrator access for all users","description":"A broad group has administrator privileges.","severity":"CRITICAL","check":lambda r: has(r.get("principal"), "everyone") and has(r.get("role"), "admin")},
 {"id":"ID-02","category":"identity","title":"MFA disabled","description":"Multi-factor authentication is not enabled.","severity":"HIGH","check":lambda r: not truthy(r.get("mfa_enabled"))},
 {"id":"ID-03","category":"identity","title":"Excessive permissions","description":"Identity has wildcard permissions.","severity":"HIGH","check":lambda r: truthy(r.get("wildcard_permissions"))},
 {"id":"ID-04","category":"identity","title":"Inactive account enabled","description":"An inactive account is still enabled.","severity":"MEDIUM","check":lambda r: truthy(r.get("inactive")) and truthy(r.get("enabled"))},
 {"id":"ID-05","category":"identity","title":"Password never expires","description":"Password expiry is disabled for this account.","severity":"MEDIUM","check":lambda r: truthy(r.get("password_never_expires"))},
 {"id":"CP-01","category":"compute","title":"Compute instance has public IP","description":"A compute instance has a public IP address.","severity":"MEDIUM","check":lambda r: truthy(r.get("public_ip"))},
 {"id":"CP-02","category":"compute","title":"Compute disk unencrypted","description":"The compute disk is not encrypted.","severity":"HIGH","check":lambda r: not truthy(r.get("disk_encrypted"))},
 {"id":"CP-03","category":"compute","title":"Legacy image in use","description":"The instance uses an image marked as legacy.","severity":"MEDIUM","check":lambda r: truthy(r.get("legacy_image"))},
 {"id":"CP-04","category":"compute","title":"Monitoring disabled","description":"Compute monitoring is not enabled.","severity":"LOW","check":lambda r: not truthy(r.get("monitoring"))},
 {"id":"CP-05","category":"compute","title":"Automatic updates disabled","description":"Automatic security updates are disabled.","severity":"MEDIUM","check":lambda r: not truthy(r.get("auto_updates"))},
 {"id":"DB-01","category":"database","title":"Database publicly accessible","description":"Database accepts public network access.","severity":"CRITICAL","check":lambda r: truthy(r.get("public_access"))},
 {"id":"DB-02","category":"database","title":"Database encryption disabled","description":"Database encryption at rest is disabled.","severity":"HIGH","check":lambda r: not truthy(r.get("encryption"))},
 {"id":"DB-03","category":"database","title":"Backups disabled","description":"Automated database backups are disabled.","severity":"HIGH","check":lambda r: not truthy(r.get("backups"))},
 {"id":"DB-04","category":"database","title":"Weak database authentication","description":"Database authentication is marked as weak.","severity":"HIGH","check":lambda r: has(r.get("authentication"), "password_only")},
 {"id":"DB-05","category":"database","title":"Audit logging disabled","description":"Database audit logging is not enabled.","severity":"MEDIUM","check":lambda r: not truthy(r.get("audit_logging"))},
]
