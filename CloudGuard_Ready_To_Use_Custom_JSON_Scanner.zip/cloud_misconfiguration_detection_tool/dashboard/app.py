from flask import Flask, render_template, redirect, url_for, request, flash, send_file, abort
from pathlib import Path
import sys
import json
from werkzeug.utils import secure_filename

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from database.database import AuditDatabase
from scan_service import ScanService
from utils.export_reports import ReportExporter

app = Flask(__name__)
app.secret_key = "local-academic-prototype-change-before-deployment"
db = AuditDatabase()
service = ScanService(db)
exporter = ReportExporter(db)

@app.route("/")
def index():
    latest = db.latest_scan()
    findings = db.findings(latest["id"]) if latest else []
    history = db.history(10)
    return render_template("index.html", latest=latest, findings=findings, history=history)

@app.post("/run-scan")
def run_scan():
    try:
        scan_id, dataset, summary, findings = service.run_scan()
        flash(f"Scan #{scan_id} completed using simulated dataset '{dataset}'.", "success")
    except Exception as exc:
        app.logger.exception("Scan failed")
        flash(f"Scan failed: {exc}", "error")
    return redirect(url_for("index"))

@app.post("/run-cloud-scan/<provider>")
def run_cloud_scan(provider):
    try:
        scan_id, label, summary, findings = service.run_cloud_scan(provider)
        flash(f"Read-only live scan #{scan_id} completed: {label}. {summary['finding_count']} finding(s).", "success")
    except Exception as exc:
        app.logger.exception("Live cloud scan failed")
        flash(str(exc), "error")
    return redirect(url_for("index"))

@app.get("/example-json")
def download_example_json():
    path = ROOT / "cloud_data" / "custom_scan_example.json"
    return send_file(path, as_attachment=True, download_name="cloudguard_custom_scan_example.json")

@app.route("/custom-scan", methods=["GET", "POST"])
def custom_scan():
    """Scan user-supplied JSON configurations locally; no cloud account required."""
    if request.method == "GET":
        return render_template("custom_scan.html")
    upload = request.files.get("config_file")
    if not upload or not upload.filename:
        flash("Choose a JSON configuration file first.", "error")
        return redirect(url_for("custom_scan"))
    if not upload.filename.lower().endswith(".json"):
        flash("Only .json files are accepted.", "error")
        return redirect(url_for("custom_scan"))
    try:
        raw = upload.read(1_000_001)
        if len(raw) > 1_000_000:
            raise ValueError("File is too large. Maximum size is 1 MB.")
        payload = json.loads(raw.decode("utf-8-sig"))
        configurations = _normalize_custom_config(payload)
        findings = service.rules.run(configurations)
        from engine.risk_engine import score_findings
        from remediation.recommendations import enrich as add_recommendations
        from compliance.mapping import enrich as add_compliance
        findings, summary = score_findings(findings)
        findings = add_recommendations(findings)
        findings = add_compliance(findings)
        label = "CUSTOM JSON · " + secure_filename(upload.filename)[:80]
        scan_id = db.save_scan(label, summary, findings)
        flash(f"Custom JSON scan #{scan_id} completed: {summary['finding_count']} finding(s). This scanned uploaded data, not a live cloud account.", "success")
        return redirect(url_for("index"))
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError, TypeError) as exc:
        flash(f"Could not scan JSON: {exc}", "error")
        return redirect(url_for("custom_scan"))
    except Exception as exc:
        app.logger.exception("Custom JSON scan failed")
        flash(f"Custom JSON scan failed: {exc}", "error")
        return redirect(url_for("custom_scan"))

def _normalize_custom_config(payload):
    """Accept category->list JSON or a list of resources with category fields."""
    categories = ("storage", "network", "identity", "compute", "database")
    result = {category: [] for category in categories}
    if isinstance(payload, dict):
        # Support a wrapped object such as {"resources": [...]}
        if isinstance(payload.get("resources"), list):
            payload = payload["resources"]
        else:
            for category in categories:
                values = payload.get(category, [])
                if not isinstance(values, list):
                    raise ValueError(f"'{category}' must be a JSON list.")
                if not all(isinstance(item, dict) for item in values):
                    raise ValueError(f"Every item in '{category}' must be an object.")
                result[category] = values
            if not any(result.values()):
                raise ValueError("JSON must contain resource lists named storage, network, identity, compute, or database.")
            return result
    if isinstance(payload, list):
        for item in payload:
            if not isinstance(item, dict):
                raise ValueError("Every resource in the list must be a JSON object.")
            category = str(item.get("category", "")).lower()
            if category not in categories:
                raise ValueError("Each resource needs category: storage, network, identity, compute, or database.")
            result[category].append(item)
        if not any(result.values()):
            raise ValueError("The resource list is empty.")
        return result
    raise ValueError("Use a JSON object with category lists, or a list of resources with a category field.")

@app.route("/setup")
def setup_guide():
    return render_template("setup.html")

@app.route("/findings")
def all_findings():
    latest = db.latest_scan()
    if not latest:
        return redirect(url_for("index"))
    findings = db.findings(latest["id"])
    query = request.args.get("q", "").strip().lower()
    severity = request.args.get("severity", "")
    category = request.args.get("category", "")
    findings = [f for f in findings if query in (f.get("title","") + " " + f.get("resource_name","") + " " + f.get("description","")).lower()]
    if severity:
        findings = [f for f in findings if f.get("severity") == severity]
    if category:
        findings = [f for f in findings if f.get("category") == category]
    return render_template("findings.html", latest=latest, findings=findings, q=query, severity=severity, category=category)

@app.post("/delete-scan/<int:scan_id>")
def delete_scan(scan_id):
    db.delete_scan(scan_id)
    flash(f"Deleted scan #{scan_id}.", "success")
    return redirect(url_for("index"))

@app.post("/clear-history")
def clear_history():
    db.clear_history()
    flash("Scan history cleared.", "success")
    return redirect(url_for("index"))

@app.get("/download/<int:scan_id>/<fmt>")
def download_report(scan_id, fmt):
    try:
        path = exporter.export(scan_id, fmt)
    except ValueError:
        abort(404)
    return send_file(path, as_attachment=True, download_name=path.name)

if __name__ == "__main__":
    print("Open http://127.0.0.1:5000 in your browser.")
    app.run(host="127.0.0.1", port=5000, debug=False)
