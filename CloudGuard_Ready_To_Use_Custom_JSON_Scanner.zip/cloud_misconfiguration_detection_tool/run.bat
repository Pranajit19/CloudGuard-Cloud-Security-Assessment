@echo off
python -m pip install -r requirements.txt
python dashboard\app.py
pause
